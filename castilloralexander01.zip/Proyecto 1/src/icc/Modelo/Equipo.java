/**
 * clase que determina la estructura del objeto Equipo
 * @author Alexander Adalid Castillo Romero
 */
package icc.Modelo;

public class Equipo {
    /**
     * nombre de la clase y acceso
     */
    /**
     * atributos */
    private String nombre;
    private int id;
    private int puntos;
    private int totalAFavor;
    private int totalEnContra;
    private int setsAFavor;
    private int setsEnContra;
    private int partidosGanados;
    private int partidosPerdidos;


/**
 * Constructor del objeto Equipo
 * @param nombre recibe un string que indica el nombre del equipo
 * @param id recibe un int que determina su lugar dentro de un arreglo de equipos
 * @param partidosGanados recibe un int que indica la cantidad de partidos ganados
 * @param partidosPerdidos recibe un int que indica la cantidad de partidos perdidos
 * @param totalAFavor recibe un int que indica el total de puntos que ha hecho en contra de otros equipos
 * @param totalEnContra recibe un int que indica el total de puntos que se han hecho en su contra
 * @param setsAFavor recibe un int que indica la cantidad de sets que ha ganado
 * @param setsEnContra recibe un int que indica la la cantiad de sets que ha perdido
 * @param puntos 
 */
    public Equipo(String nombre, int id, int partidosGanados, int partidosPerdidos, int totalAFavor, int totalEnContra, int setsAFavor, int setsEnContra, int puntos) {
        this.partidosPerdidos = partidosPerdidos;
        this.partidosGanados = partidosGanados;
        this.nombre = nombre;
        this.id = id;
        this.totalAFavor = totalAFavor;
        this.totalEnContra = totalEnContra;
        this.setsAFavor = setsAFavor;
        this.setsEnContra = setsEnContra;
        this.puntos = puntos;
    }
/** constructor vacio */
    public Equipo() {
    }

    public String nombre() { 
        /**
         * metodo que devuelve el nombre del equipo
         */
        return this.nombre;
    }

    public int id() {
        /**
         * metodo que devuelve el id del equipo
         */
        return this.id;
    }

    public int puntos() {
        /**
         * metodo que devuelve los puntos del equipo
         */
        return this.puntos;
    }

    public int totalAFavor() {
        /**
         * metodo que devuelve los puntos a favor del equipo
         */
        return this.totalAFavor;
    }

    public int totalEnContra() {
        /**
         * metodo que devuelve los puntos en contra del equipo
         */
        return this.totalEnContra;
    }

    public int setsAFavor() {
        /**
         * metodo que devuelve los sets a favor del equipo
         */
        return this.setsAFavor;
    }

    public int setsEnContra() {
        /**
         * metodo que devuelve los sets en contra del equipo
         */
        return this.setsEnContra;
    }

    public int partidosGanados() {
        /**
         * metodo que devuelve los partidos ganados del equipo
         */
        return this.partidosGanados;
    }

    public int partidosPerdidos() {
        /**
         * metodo que devuelve los partidos perdidos del equipo
         */
        return this.partidosPerdidos;
    }

    public void setNombre (String nombre) {
        /**
         * metodo que asigna el nombre del equipo
         */
        this.nombre = nombre;
    }

    public void setId (int id) {
        /**
         * metodo que asigna el id del equipo
         */
        this.id = id;
    }

    public void setPuntos (int puntos) {
        /**
         * metodo que asigna los puntos del equipo
         */
        this.puntos = puntos;
    }

    public void setTotalAFavor (int totalAFavor) {
        /**
         * metodo que asigna el total de puntos a favor del equipo
         */
        this.totalAFavor = totalAFavor;
    }

    public void setSetsAFavor (int setsAFavor) {
        /**
         * metodo que asigna el total de sets a favor del equipo
         */
        this.setsAFavor = setsAFavor;
    }

    public void setTotalEnContra (int totalEnContra) {
        /**
         * metodo que asigna el total de puntos en contra del equipo
         */
        this.totalEnContra = totalEnContra;
    }

    public void setSetsEnContra (int setsEnContra) {
        /**
         * metodo que asigna el total de sets en contra del equipo
         */
        this.setsEnContra = setsEnContra;
    }

    public void setPartidosGanados (int partidosGanados) {
        /**
         * metodo que asigna el total de partidos ganados del equipo
         */
        this.partidosGanados = partidosGanados;
    }

    public void setPartidosPerdidos (int partidosPerdidos) {
        /**
         * metodo que asigna el total de partidos perdidos del equipo
         */
        this.partidosPerdidos = partidosPerdidos;
    }
}
