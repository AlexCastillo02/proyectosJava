/**
 * Clase sin parametros que realiza la simulacion de los 4 a 5 sets utilizando puntuaciones pseudoaleatorias
 * 
 * @author Alexander Adalid Castillo Romero
 */

package icc.Simulador;

import icc.Modelo.Equipo;
import java.util.Random;

public class Partido {

    /**
     * metodo que recibe un arreglo de objetos de tipo Equipo, su ubicacion en el arreglo y muestra 
     * @param equipos arreglo de objetos de tipo Equipo
     * @param equipoLocal entero que indica la posicion del primer equipo en el arreglo equipos[]
     * @param equipoVisitante entero que indica la posicion del segundo equipo en el arreglo equipos[]
     */
    public void partidoJugado(Equipo equipos[], int equipoLocal, int equipoVisitante) {

        int set;
                set = 0;
                int local;
                int visitante;
                int setsLocal;
                int setsVisitante;
                setsLocal = 0;
                setsVisitante = 0;
                local = 0;
                visitante = 0;
                Random generador = new Random();

        System.out.println(equipos[equipoLocal].nombre() + " vs " + equipos[equipoVisitante].nombre()); /**
        *Mensaje que muestra entre quienes será el enfrentamiento 
        */
                for (set = 0; set < 5; set++) {
                    /**
                     * Ciclo for que limita el enfrentamiento a 5 sets 
                     */
                    if (set < 4) { 
                        /**
                         * Condicional que determina cómo se juegan los primeros 4 sets 
                         */
                    local = generador.nextInt(25) + 1; 
                    /**
                     * Método que calcula de manera pseudoaleatoria la puntuación para uno de los equipos 
                     */
                    visitante = generador.nextInt(25) + 1; 
                    /**
                     * Método que calcula de manera pseudoaleatoria la puntuación para uno de los equipos 
                     */
                    if (visitante == local) { /**
                        *Metodo que se encarga de que las puntuaciones no sean iguales 
                        */
                        visitante = visitante - 1;
                    }
                    if (visitante + 1 == local) { 
                        /**
                         * Condicional que permite que la diferencia entre puntuaciones se de mínimo 2 para el resultado ganador
                         */
                        visitante = visitante - 1;
                    }
                    if (local + 1 == visitante) { /**
                        * Condicional que permite que la diferencia entre puntuaciones se de mínimo 2 para el resultado ganador
                        */
                        local = local - 1;
                    }
                    if (local > visitante) { 
                        /**
                         * Condicional que determina lo que sucede si gana el primer equipo 
                         */
                        local = 25; /**
                        *Si en la simulacion el equpo local obtuvo un valor mayor que el otro equipo, su puntuacion se actualiza a 25 para que se le cuente como ganador del set, esta variable le registra los 25 puntos
                         */
                        setsLocal++; 
                        /** 
                        *incremento a la cantidad de sets a favor del equipo local
                        */

                        /**
                         * En caso de que el equipo local haya ganado, este conjunto de metodos asignan valores al objeto Equipo en el arreglo equipos[equipoLocal] y al otro equipo de modo que se registren los puntos, sets y partidos a favor y en contra para cada uno
                         */
                        equipos[equipoLocal].setSetsAFavor(equipos[equipoLocal].setsAFavor() + 1);
                        equipos[equipoLocal].setSetsEnContra(equipos[equipoVisitante].setsAFavor());
                        equipos[equipoVisitante].setSetsEnContra(equipos[equipoLocal].setsAFavor());
                        equipos[equipoVisitante].setTotalAFavor(equipos[equipoVisitante].totalAFavor() + visitante);
                        equipos[equipoLocal].setTotalAFavor(equipos[equipoLocal].totalAFavor() + local);
                        equipos[equipoVisitante].setTotalEnContra(equipos[equipoLocal].totalAFavor());
                        equipos[equipoLocal].setTotalEnContra(equipos[equipoVisitante].totalAFavor());
                    } 
                    if (visitante > local) { 
                        /**
                         * Condicional que asigna valores a los equipos si gana el segundo equipo, funciona de igual manera que el proceso anterior, pero los lugares de los equipos estan invertidos
                         */
                        visitante = 25;
                        setsVisitante++;
                        equipos[equipoVisitante].setSetsAFavor(equipos[equipoVisitante].setsAFavor() + 1);
                        equipos[equipoVisitante].setSetsEnContra(equipos[equipoLocal].setsAFavor());
                        equipos[equipoLocal].setSetsEnContra(equipos[equipoVisitante].setsAFavor());
                        equipos[equipoLocal].setTotalAFavor(equipos[equipoLocal].totalAFavor() + local);
                        equipos[equipoVisitante].setTotalAFavor(equipos[equipoVisitante].totalAFavor() + visitante);
                        equipos[equipoVisitante].setTotalEnContra(equipos[equipoLocal].totalAFavor());
                        equipos[equipoLocal].setTotalEnContra(equipos[equipoVisitante].totalAFavor());
                    }
                    System.out.println(local + " - " + visitante); 
                    /**
                    * Mensaje que muestra los resultados del set jugado 
                    */
                    } else { 
                        /**
                         * Parte del ciclo if que determina como se juega un quinto set 
                         */
                    if (setsLocal == 3 || setsVisitante == 3) { 
                        /**
                         * Ciclo if que determina si se juega un quinto set o no en caso de que algún equipo tenga ya 3 sets ganados 
                         */
                        local = 0;
                        visitante = 0;
                    } else { 
                        /**
                         * Parte del ciclo if que determina cómo se juega el quinto set
                         */

                         /**
                          * Proceso que funciona igual que la asignacion de valores anterior, pero en este caso solo ocurre si se juega un quinto set
                          */

                    local = generador.nextInt(15) + 1;
                    /**
                     * Random que calcula la puntuacion para ganar topada a 15 en lugar de a 25
                     */
                    visitante = generador.nextInt(15) + 1;
                    if (visitante + 1 == local) {
                        visitante = visitante - 1;
                    }
                    if (local + 1 == visitante) {
                        local = local - 1;
                    }
                    if (local > visitante) {
                        local = 15;
                        setsLocal++;
                        equipos[equipoLocal].setSetsAFavor(equipos[equipoLocal].setsAFavor() + 1);
                        equipos[equipoLocal].setSetsEnContra(equipos[equipoVisitante].setsAFavor());
                        equipos[equipoVisitante].setSetsEnContra(equipos[equipoLocal].setsAFavor());
                        equipos[equipoVisitante].setTotalAFavor(equipos[equipoVisitante].totalAFavor() + visitante);
                        equipos[equipoLocal].setTotalAFavor(equipos[equipoLocal].totalAFavor() + local);
                        equipos[equipoVisitante].setTotalEnContra(equipos[equipoLocal].totalAFavor());
                        equipos[equipoLocal].setTotalEnContra(equipos[equipoVisitante].totalAFavor());
                    } else {
                        visitante = 15;
                        setsVisitante++;
                        equipos[equipoVisitante].setSetsAFavor(equipos[equipoVisitante].setsAFavor() + 1);
                        equipos[equipoVisitante].setSetsEnContra(equipos[equipoLocal].setsAFavor());
                        equipos[equipoLocal].setSetsEnContra(equipos[equipoVisitante].setsAFavor());
                        equipos[equipoVisitante].setTotalAFavor(equipos[equipoVisitante].totalAFavor() + visitante);
                        equipos[equipoLocal].setTotalAFavor(equipos[equipoLocal].totalAFavor() + local);
                        equipos[equipoVisitante].setTotalEnContra(equipos[equipoLocal].totalAFavor());
                        equipos[equipoLocal].setTotalEnContra(equipos[equipoVisitante].totalAFavor());
                    }
                }
                    System.out.println(local + " - " + visitante);

                }
            }
            /**
             * Finaliza Ciclo que hace la simulación de las puntuaciones
             */
            if (setsLocal == 3) { 
                /**
                 * Ciclo if que determina a quién se le suma el partido ganado 
                 */
                equipos[equipoLocal].setPartidosGanados(equipos[equipoLocal].partidosGanados() + 1);
                equipos[equipoVisitante].setPartidosPerdidos(equipos[equipoLocal].partidosGanados());
            } else {
                equipos[equipoVisitante].setPartidosGanados(equipos[equipoVisitante].partidosGanados() + 1);
                equipos[equipoLocal].setPartidosPerdidos(equipos[equipoVisitante].partidosGanados());
            }
            /**
             * Mensaje que muestra cuantos sets obtuvo cada equipo
             */
            System.out.println("Sets equipo " + equipos[equipoLocal].nombre() + " = " + setsLocal);
            System.out.println("Sets equipo " + equipos[equipoVisitante].nombre() + " = " + setsVisitante);
            System.out.println();
            setsLocal = 0; 
            /**
             *            Actualización de las variables de los sets para que se pueda empezar el ciclo desde 0 
             */
            setsVisitante = 0;        
        }

    }
    

