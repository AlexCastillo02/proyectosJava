/**
 * clase sin atributos que recibe parametro para desplegar la informacion de algun equipo en cuanto se solicite
 * @author Alexander Adalid Castillo Romero
 * 
 */


package icc.Simulador;
import icc.Modelo.Equipo;

public class InformacionEquipo {
    /**
     * 
     * @param equipos recibe un objeto de tipo Equipo alojado en un arreglo llamado equipos
     * @param x recibe un int que le indica la posicion del arreglo en la cual se encuentra el equipo solicitado
     */
    public void mostrarInformacion(Equipo equipos[], int x){ 
        /**
         * metodo que imprime los atributos del objeto Equipo solicitado
         */
                    System.out.println();
                    System.out.println("ID: " + equipos[x].id());
                    System.out.println("Nombre: " + equipos[x].nombre());
                    System.out.println("Anotaciones: " + equipos[x].puntos());
                    System.out.println("Total a favor: " + equipos[x].totalAFavor());
                    System.out.println("Total en contra: " + equipos[x].totalEnContra());
                    System.out.println("Sets a favor: " + equipos[x].setsAFavor());
                    System.out.println("Sets en contra: " + equipos[x].setsEnContra());
                    System.out.println("Juegos ganados: " + equipos[x].partidosGanados());
                    System.out.println("Juegos perdidos: " + equipos[x].partidosPerdidos());
                    System.out.println();
    }

}
