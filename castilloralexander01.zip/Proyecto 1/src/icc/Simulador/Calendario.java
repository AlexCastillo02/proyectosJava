/**
 * clase sin atributos que calcula la cantidad de rondas, enfrentamientos por ronda y asigna entre que equipos seran los enfrentamientos
 * @author Alexander Adalid Castillo Romero
 */
package icc.Simulador;

public class Calendario {
    /**
     * metodo que devuelve un int que indica cuantas rondas se jugaran durante el torneo
     * @param numeroEquipos parametro que indica sobre cuantos equipos calcular la cantidad de rondas
     * @return devuelve un int que indica las rondas a jugar en la simulacion
     */
    public int generadorRondas(int numeroEquipos){
        int rondas;
        if (numeroEquipos % 2 != 0) {
            rondas = numeroEquipos;
        } else {
            rondas = numeroEquipos - 1;
        }
        return rondas;
    }

    public int generadosPartidos(int numeroEquipos) {
        /**
         * metodo que indica cuantas simulaciones de partido se ejecutaran por ronda
         * 
         */
        int partidos;
        if (numeroEquipos % 2 != 0) {
            partidos = (numeroEquipos - 1) / 2;
        } else {
            partidos = numeroEquipos / 2;
        }
        return partidos;
    }
/**
 * Metodo que determina el id del equipo que jugara un enfrentamiento
 * @param rondaActual parametro que indica la ronda que se esta jugando
 * @param partidoEnTurno parametro que indica que numero de partido se esta jugando
 * @param numeroEquipos parametro que indica el numoero total de equipos en el torneo
 * @param equiposPares parametro que determina si se debe hacer el calendario para equipos pares o no
 * @return devuelve un int que indica la posicion en el arreglo equipos del primer Equipo que participara en la simulacion
 */
    public int generadorEquipo1(int rondaActual, int partidoEnTurno, int numeroEquipos, boolean equiposPares) {
        int equipo1;
        if (equiposPares = false) {
            if (partidoEnTurno < (numeroEquipos / 2)) {
            numeroEquipos = numeroEquipos - 1;
            equipo1 = (rondaActual + (partidoEnTurno + 1)) % numeroEquipos;
            } else {
                equipo1 = rondaActual;
            }
            
        } else {
            equipo1 = (rondaActual + (partidoEnTurno + 1)) % numeroEquipos;
        }
        return equipo1;
    }
    /**
     * Metodo que determina el segundo equipo del enfrentamiento
     * @param rondaActual recibe la ronda que se esta jugando
     * @param partidoEnTurno recibe el partido en turno
     * @param numeroEquipos recibe el numero total de equipo
     * @param equiposPares decide si se ejecuta la instruccion para numeros pares o no 
     * @return regresa el lugar del segundo equipo 
     */
    public int generadorEquipo2(int rondaActual, int partidoEnTurno, int numeroEquipos, boolean equiposPares) {
        int equipo2;
        if (equiposPares = false) {
            if (partidoEnTurno < (numeroEquipos / 2)) {
                numeroEquipos = numeroEquipos - 1;
                equipo2 = (((rondaActual + numeroEquipos) - (partidoEnTurno + 1)) % numeroEquipos);
            } else {
                equipo2 = numeroEquipos;
            }
        } else {
            equipo2 = (((rondaActual + numeroEquipos) - (partidoEnTurno + 1)) % numeroEquipos);
        }
        return equipo2;
    }

}
