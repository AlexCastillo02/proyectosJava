/**
 * Clase que ejecuta el simulador de un torneo roun robin de volleybol
 * 
 * @author Alexander Adalid Castillo Romero
 * 
 */
package icc;
import icc.Modelo.Equipo;
import java.util.Random;
import java.util.Scanner;
import icc.Simulador.Calendario;
import icc.Simulador.InformacionEquipo;
import icc.Simulador.Partido;

public class Prueba {

    public static void main(String args[]) {
        Equipo equipo = new Equipo();
        boolean equiposPares;
        boolean hayGanador; 
        /**
        * Variable que determina si ya existe un ganador 
        */
        int opcion; 
        /** 
         * Variable que permite introducir un entero para seleccionar una opción en los menús 
         */
        String nombre; 
        /** 
         * Variable con la que se asignará un nombre a cada equipo 
         */
        int numeroEquipos; 
        /**
         * Variable que registra de cuántos equipos se conforma la simulación 
         */
        int i; 
        /**Variable utilizada como referencia para registrar los equipos en el arreglo */
        i = 0; 
        /**
         * Variable que ayuda a determinar en que momento correr en menú para cuando se simularon todos los partidos 
         */
        hayGanador = false;
        int numeroEnfrentamientos; 
        /**
         * Variable que registra cuantos enfrentamientos ocurriran 
         */
        int rondasRealizadas; 
        /**
         * Variable que registra la cantidad de rondas jugadas 
         */
        rondasRealizadas = 0;
        int rondasPorSimulacion;
        int equipoDescansa;
        Scanner scan = new Scanner(System.in); 
        /**
         * Método Scanner para recibir datos del usuario 
         */
        Random generador = new Random();
        System.out.println("Este es un simulador de un torneo de volleybol de sala"); 
        /**
         * Mensaje de bienvenida que aparece solo en el inicio del programa 
         */
        System.out.println("De cuantos equipos quieres hacer la simulacion?"); 
        /**
         * Petición al usuario de la cantidad de equipos para la simulación 
         */
        numeroEquipos = scan.nextInt();
        scan.nextLine();
        int numeroRondas;
        int numeroPartidos;
        Calendario rondas = new Calendario();
        numeroRondas = rondas.generadorRondas(numeroEquipos);
        numeroPartidos = rondas.generadosPartidos(numeroEquipos); 
        /**
         * Método que determina la cantidad de partidos que se jugarán por ronda 
         */

        if (numeroEquipos % 2 != 0) { 
            /**
             * Condicional que determina si uno de los equipos descansa en cada ronda 
            */
            equiposPares = false;
        } else {
            equiposPares = true;
        }

        Equipo[] equipos; 
        /**
         * Declaración de arreglo de objetos de la clase Equipo 
         */
        equipos = new Equipo[numeroEquipos]; 
        /**
         * Asignación de la longitud del arreglo equipos 
         */
        for (i = 0; numeroEquipos > i; i++) { 
            /**
             * Ciclo for que determina registra el nombre e id para los equipos
             */
            equipos[i] = new Equipo();
            equipos[i].setId(i); 
            /**
             * Método que asigna el valor del id a cada equipo
             */
            System.out.println("Dame un nombre para el equipo " + i);
            nombre = scan.nextLine();
            equipos[i].setNombre(nombre); 
            /**
             * Método que asigna nombre a cada equipo
             */
        }
        numeroEnfrentamientos = (numeroEquipos * (numeroEquipos - 1)) / 2; 
        /**
         * Fórmula que calcula la cantidad total de enfrentamientos que se realizarán
         * 
         */
        /**
         * Estructura while para determinar si debe seguir corriendo el menú en el que se realizan simulaciones o se consultan las puntuaciones disponibles hasta el momento
         * 
         */
        while (rondasRealizadas < numeroRondas) {
            System.out.println("1. Consultar puntuaciones"); 
            /** 
             * Menú que indica las acciones que se pueden realizar antes de que se finalice el torneo
             */
            System.out.println("2. Continuar simulacion");
            System.out.println("0. Salir");
            opcion = scan.nextInt();
            switch (opcion) { 
                /**
                 * Estructura switch que indica lo que se debe realizar en cada caso del menú
                 */
                case 0:
                System.out.println("Vuelve pronto!"); 
                /**
                 * Mensaje de despedida en caso de que el usuario decida finalizar el programa
                 */
                System.exit(0); 
                /**
                 * Instrucción que finaliza la ejecución
                 */
                break;
                case 1:
                int p;
                p = 0;
                for (p = 0; p < equipos.length; p++) { 
                    /**
                     * Ciclo for que despliega la información actual de cada equipo
                     */
                    InformacionEquipo puntuaciones = new InformacionEquipo();
                    puntuaciones.mostrarInformacion(equipos, p); 
                    /**
                     * Método que despliega la información de todos los equipos hasta la ronda actual
                     */
                }
                break;
                case 2:
                int equipoLocal;
                int equipoVisitante;
                int partidoEnTurno;
                Partido partidoEnJuego = new Partido();






                for (partidoEnTurno = 0; partidoEnTurno < numeroPartidos; partidoEnTurno++) {
                    Calendario equiposPartido = new Calendario(); 
                    /** 
                     * Crea una nueva instancia para la calendarizacion
                     */
                    equipoLocal = equiposPartido.generadorEquipo1(rondasRealizadas, partidoEnTurno, numeroEquipos, equiposPares); 
                    /**
                     * Genera el id del primer equipo del enfrentamiento
                     */
                    equipoVisitante = equiposPartido.generadorEquipo2(rondasRealizadas, partidoEnTurno, numeroEquipos, equiposPares); 
                    /**
                     * Genera el id del segundo equipo del enfrentamiento
                     */
                    partidoEnJuego.partidoJugado(equipos, equipoLocal, equipoVisitante); 
                    /**
                     * Realiza la simulacion de un enfrentamiento
                     */
                }
                    if (equiposPares == false) { 
                        /**
                         * En caso de que la cantidad de equipos no sea par, imprime el id del equipo que no juega en la ronda actual
                         */
                    System.out.println("Descansa equipo " + rondasRealizadas);
                }






                rondasRealizadas ++;
                if (rondasRealizadas == numeroRondas) {
                    hayGanador = true;
                }
                break;
        }
    }
    /**
     * Menú que se muestra solo cuando ya ocurrieron todas las simulaciones
     * 
     */
            System.out.println("Ya finalizo el torneo"); 
            /**
             * Mensaje de finalización
             */
            System.out.println();
        while (hayGanador = true) { 
            /**
             * listado de opciones disponibles cuando ya hay un ganador
             */
            System.out.println("1. Consultar todas las puntuaciones");
            System.out.println("2. Consultar alguna puntuacion en particular");
            System.out.println("3. Ver campeon");
            System.out.println("0. Salir");
            opcion = scan.nextInt();
            switch (opcion) { 
                /**
                 * Estructura switch para ejecutar las opciones del menú
                 */
                case 0: 
                /**
                 * Caso de salida
                 */
                System.out.println("Vuelve pronto!");
                System.exit(0);
                break;
                case 1:
                System.out.println("Torneo de volleybol, resumen final: "); 
                /**
                 * Caso que despliega todas las puntuaciones
                 */
                int apoyoFor;
                apoyoFor = 0;
                for (apoyoFor = 0; apoyoFor < equipos.length; apoyoFor++) {
                    InformacionEquipo resumen = new InformacionEquipo();
                    resumen.mostrarInformacion(equipos, apoyoFor);
                }
                break;
                case 2: 
                /**
                 * Caso que permite consultar un equipo en particular
                 */
                int equiosConsulta;
                equiosConsulta = 0;
                System.out.println("Elige el equipo a consultar");
                for (equiosConsulta = 0; equiosConsulta < equipos.length; equiosConsulta ++) { 
                    /**
                     * Ciclo for que muestra los equipos disponibles para consilta
                     */
                    System.out.println(equipos[equiosConsulta].id() + ". " + equipos[equiosConsulta].nombre());
                }
                opcion = scan.nextInt();
                InformacionEquipo option = new InformacionEquipo();
                option.mostrarInformacion(equipos, opcion); 
                /**
                 * Método que despliega la información del equipo con el id seleccionado
                 */
                break;
                case 3: 
                /**
                 * Caso que identifica el equipo con más juegos ganados
                 */
                int equipoCampeon;
                Equipo equipoGanador = equipos[0];
                for (int k = 1; k < equipos.length; k++) { 
                    /**
                     * Ciclo for que compara la cantidad de juegos ganados y almacena el id del equipo que tenga más
                     */
                    if (equipos[k].partidosGanados() > equipoGanador.partidosGanados()) {
                        equipoGanador = equipos[k];
                    }
                }
                    InformacionEquipo ganador = new InformacionEquipo();
                    ganador.mostrarInformacion(equipos, equipoGanador.id());
                 /**
                  * Método que despliega la información del equipo campeón
                  * 
                  */
                break;
        }
    }
}
}
